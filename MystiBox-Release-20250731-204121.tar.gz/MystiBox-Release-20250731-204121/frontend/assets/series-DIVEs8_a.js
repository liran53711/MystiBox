import{I as e}from"./index-o0ffgrYm.js";const s={getAll:()=>e.get("/series"),getById:r=>e.get(`/series/${r}`)};export{s as seriesApi};
